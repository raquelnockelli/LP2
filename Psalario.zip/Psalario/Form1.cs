﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
        
    {
        Double salarioBruto = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void txtNomeFuncionario_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNomeFuncionario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter inválido");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Double Filhos = 0, salarioFamilia, salarioLiquido=0, descINSS, descIRPF;

            //convertendo pra double o numero de filhos
            Filhos = Convert.ToDouble(NumeroFilhos.Value);

            //convertendo o numero da mascara para double
            double.TryParse(mskbxSalario.Text, out salarioBruto);
            
             //verificando descontos do inss
            if (salarioBruto <= 800.47)
            {
                txtAliquotaINSS.Text = "7,65%";
                descINSS = 0.0765 * salarioBruto;
                txtDescINSS.Text = descINSS.ToString("N2");
            }
            else if (salarioBruto <= 1050.00)
            {
                txtAliquotaINSS.Text = "8,65%";
                descINSS = 0.0865 * salarioBruto;
                txtDescINSS.Text = descINSS.ToString();
            }
            else if (salarioBruto <= 1400.77)
            {
                txtAliquotaINSS.Text = "9,00%";
                descINSS = 0.0865 * salarioBruto;
                txtDescINSS.Text = descINSS.ToString("N2");
            }
            else if (salarioBruto <= 2801.56)
            {
                txtAliquotaINSS.Text = "11,00%";
                descINSS = 0.11 * salarioBruto;
                txtDescINSS.Text = descINSS.ToString("N2");
            }
            else
            {
                txtAliquotaINSS.Text = "Teto";
                descINSS = 308.17;
                txtDescINSS.Text = descINSS.ToString("N2");
            }

            //verificando descontos do IRPF
            if (salarioBruto <= 1257.13)
            {
                txtAliquotaIRPF.Text = "Isento";
                descIRPF = 0;
                txtDescIRPF.Text = descIRPF.ToString("N2");
            }
            else if (salarioBruto <= 2512.08)
            {
                txtAliquotaIRPF.Text = "15,00%";
                descIRPF = 0.15 * salarioBruto;
                txtDescIRPF.Text = descIRPF.ToString("N2");
            }
            else
            {
                txtAliquotaIRPF.Text = "27,05%";
                descIRPF = 0.275 * salarioBruto;
                txtDescIRPF.Text = descIRPF.ToString("N2");
            }

            //verificando salario familia
           if (salarioBruto <= 435.52)
            {
                salarioFamilia = Filhos * 22.33;
                txtsalarioFamília.Text = salarioFamilia.ToString("N2");
            }
           else if (salarioBruto <= 654.61)
            {
                salarioFamilia = Filhos * 15.74;
                txtsalarioFamília.Text = salarioFamilia.ToString("N2");
            }
           else
            {
                salarioFamilia = 0;
                txtsalarioFamília.Text = salarioFamilia.ToString("N2");
            }

            salarioLiquido = salarioBruto - descINSS - descIRPF + salarioFamilia;
            txtSalarioLiquido.Text = salarioLiquido.ToString("N2");

        }


        private void txtAliquotaINSS_TextChanged(object sender, EventArgs e)
        {

        }

        
    }
}
