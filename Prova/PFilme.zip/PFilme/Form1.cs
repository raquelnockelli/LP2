﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ListAvaliacao.Items.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] PessoaNotas = new double[2, 2];
            string auxiliarNota;
            double mediaFilme1;
            double mediaFilme2;

            for (int pessoa = 0; pessoa < 2; pessoa++)
                for (int numFilme = 0; numFilme < 2; numFilme++)
                {
                    {
                        auxiliarNota = Interaction.InputBox($" Pessoa {pessoa + 1} digite a nota do Filme {numFilme + 1}",
                            "Entrada de dados");

                        if (!double.TryParse(auxiliarNota, out PessoaNotas[pessoa, numFilme]))
                        {
                            MessageBox.Show("Insira um valor válido");
                            pessoa--;
                            numFilme--;
                        }




                    }

                }


            //double[] media = new double[20];

            mediaFilme1 = (PessoaNotas[0, 0] + PessoaNotas[1, 0]) / 2;

            mediaFilme2 = (PessoaNotas[0, 1] + PessoaNotas[1, 1]) / 2;





            for (int pessoa = 0; pessoa < 2; pessoa++) {
                for (int numFilme = 0; numFilme < 2; numFilme++)
                {

                    ListAvaliacao.Items.Add($" Pessoa {pessoa + 1}  Nota filme {numFilme + 1}: {PessoaNotas[pessoa, numFilme]}");
                }
            }

            ListAvaliacao.Items.Add("-------------------------");

            ListAvaliacao.Items.Add( " Média Filme 1: " + mediaFilme1);
               ListAvaliacao.Items.Add("Média FIlme 2: " + mediaFilme2);
        }

    }
}
