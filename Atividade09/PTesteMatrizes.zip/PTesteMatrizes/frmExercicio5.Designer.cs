﻿namespace PTesteMatrizes
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listRespostas = new System.Windows.Forms.ListBox();
            this.btnConferir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listRespostas
            // 
            this.listRespostas.FormattingEnabled = true;
            this.listRespostas.ItemHeight = 16;
            this.listRespostas.Location = new System.Drawing.Point(45, 36);
            this.listRespostas.Name = "listRespostas";
            this.listRespostas.Size = new System.Drawing.Size(342, 244);
            this.listRespostas.TabIndex = 0;
            // 
            // btnConferir
            // 
            this.btnConferir.Location = new System.Drawing.Point(45, 305);
            this.btnConferir.Name = "btnConferir";
            this.btnConferir.Size = new System.Drawing.Size(342, 67);
            this.btnConferir.TabIndex = 1;
            this.btnConferir.Text = "CONFERIR";
            this.btnConferir.UseVisualStyleBackColor = true;
            this.btnConferir.Click += new System.EventHandler(this.btnConferir_Click);
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(446, 450);
            this.Controls.Add(this.btnConferir);
            this.Controls.Add(this.listRespostas);
            this.Name = "frmExercicio5";
            this.Text = "frmExercicio5";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listRespostas;
        private System.Windows.Forms.Button btnConferir;
    }
}