﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;


namespace PTesteMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}º",
                                "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Insira um valor válido");
                    i--;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
                auxiliar += x + "\n";

            MessageBox.Show(auxiliar);

        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {

            ArrayList nomes = new ArrayList() { "Ana", "Andre", "Débora", "Fátima", "João", "Otávio", "Marcelo", "Pedro", "Thais" };

            nomes.Remove("Otávio");
            string auxiliar = "";
            foreach (string nome in nomes)
            {
                auxiliar += nome + "\n";

            }
            MessageBox.Show(auxiliar);

        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliarNota;
            

            for (int aluno = 0; aluno < 20; aluno++)
                for (int notasalunos = 0; notasalunos < 3; notasalunos++)
                {
                    {
                        auxiliarNota = Interaction.InputBox($"Digite a nota {notasalunos + 1} do aluno {aluno + 1}",
                            "Entrada de dados");

                        if (!double.TryParse(auxiliarNota, out notas[aluno, notasalunos]))
                        {
                            MessageBox.Show("Insira um valor válido");
                            aluno--;
                            notasalunos--;
                        }
                    }
                }

            double[] media = new double[20];

            for (int aluno = 0; aluno < 20; aluno++)
                for (int notasalunos = 0; notasalunos < 3; notasalunos++)
                {
                    {
                        media[aluno] = (notas[aluno, notasalunos] + notas[aluno, notasalunos] + notas[aluno, notasalunos]) / 3;
                    }
                  
                }

            string auxiliar = ""; //limpa a variavel auxiliar
         
            for (int aluno = 1;aluno < 21; aluno++)
            {
                auxiliar += "Aluno: " + aluno + " média: " + media[aluno-1].ToString("N2") + "\n";
            }

            MessageBox.Show(auxiliar);



        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
           frmExercicio4 frm4 = new frmExercicio4();
            frm4.Show();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmExercicio5 frm5 = new frmExercicio5();
            frm5.Show();
        }
    }
}

