﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnConferir_Click(object sender, EventArgs e)
        {
            /*  5) Criar uma matriz 2 x 10 que representa o
                  número de alunos, e 10 é o número de questões.
                 
                 Crie um vetor(já com dados) para guardar o gabarito de
                  respostas das 10 questões que podem ser: A, B, C, D ou E.
                
                 As respostas devem ser recebidas via InputBox, e deverão
                  ser comparadas com as respostas do gabarito, e devem ser
                  mostradas em um componente ListBox.
                 
                 As respostas só podem ser A, B, C, D ou E(maiúsculas).
                 
                 Utilizar normalização para os nomes dos componentes e
                  variáveis.*/



            string[,] alunosRespostas = new string[2, 10];
            string[] respostas = new string[] { "B", "C", "A", "E", "D", "A", "C", "B", "A", "E"};
            string auxiliar = "";
            string resultado = "";

            for (int i = 0;i<2;i++)
            {
                for (int j = 0;j<10;j++)
                {
                auxiliar = Interaction.InputBox($"Digite a {j + 1}º resposta  do aluno {i + 1}",
                                "Entrada de Dados");

                    alunosRespostas[i,j] = auxiliar;

                }
            }


            for (int i = 0; i<2;i++)
            {
                for(int j = 0; j < 10; j++)
                {
                    //comparação

                    if (alunosRespostas[i, j] == respostas[j])
                        resultado = "CORRETA";
                    else resultado = "INCORRETA";


                    listRespostas.Items.Add($"A {j+1}º resposta do aluno {i+1}: {alunosRespostas[i,j]}, esta {resultado} .");
                }
            }

            /*
            foreach (string notas in alunosNotas)
            {
                auxiliar = notas;
                           

                listRespostas.Items.Add($" Resposta: {auxiliar}.");
            } */



            /*      *EX04
            
            ArrayList nomes = new ArrayList(2);
            string auxiliar = "";
            int contagem = 0;

            for (int i = 0; i < 2; i++)
            {
                auxiliar = Interaction.InputBox($"Digite {i + 1}º o nome completo ",
                                "Entrada de Dados");

                nomes.Add(auxiliar);


            }

            foreach (string nomerecebe in nomes)
            {
                auxiliar = nomerecebe;

                contagem = auxiliar.Replace(" ", "").Length;

                listNomes.Items.Add($" O nome: {auxiliar} tem {contagem} caracteres.");
            }


            */





        }
    }
}
