﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections; //adicionar

namespace PTesteMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();

            

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            /*Verifique o tamanho em caracteres (comprimento) de cada nome, DESCONTANDO
            OS ESPAÇOS EM BRANCO, e armazene esse valor em um outro vetor. No final
            carregar os nomes e valores em um componente ListBox. */

            ArrayList nomes = new ArrayList(2);
            string auxiliar = "";
            int contagem = 0;

            for (int i = 0; i < 2; i++)
            {
                auxiliar = Interaction.InputBox($"Digite {i+1}º o nome completo ",
                                "Entrada de Dados");

                nomes.Add(auxiliar);

                              
            }

            foreach(string nomerecebe in nomes)
            {
                auxiliar = nomerecebe;

                contagem = auxiliar.Replace(" ", "").Length;

                listNomes.Items.Add($" O nome: {auxiliar} tem {contagem} caracteres.");
            } 
            
                
            

         }

        private void listNomes_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
