﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMC
{
    public partial class Form1 : Form
    {

        Double altura, peso, IMC;

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtPeso.Text, out peso) ||
                    (peso <=0))
            {
                MessageBox.Show("Peso Inválido!");
                txtPeso.Focus();
            }

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {

            if (!Double.TryParse(txtAltura.Text, out altura) ||
                    (altura <=0))
            {
                MessageBox.Show("Altura Inválida!");
                txtAltura.Focus();
            }


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtIMC.Clear();
        }

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            IMC = peso / (Math.Pow(altura, 2));
            IMC = Math.Round(IMC,1);
            txtIMC.Text = IMC.ToString();

            if (IMC < 18.5)          
            {
                     MessageBox.Show("MAGREZA - GRAU 0");

            } 
            else if (IMC <= 24.9)
            {
                    MessageBox.Show("NORMAL - GRAU 0");

            }
            else if (IMC <= 29.9)
            {

                    MessageBox.Show("SOBREPESO - GRAU 1");

            }
            else if (IMC <= 39.9)
            {

                    MessageBox.Show("OBESIDADE - GRAU 2");

            }
            else
            {

                    MessageBox.Show("OBESIDADE - GRAU 3");

             }
            
        }

        

        public Form1()
        {
            InitializeComponent();
        }
        

    }
}
