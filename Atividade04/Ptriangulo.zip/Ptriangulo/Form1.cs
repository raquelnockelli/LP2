﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double valorA, valorB, valorC;

        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorC.Text, out valorC) || (valorC <= 0))
            {
                MessageBox.Show("Valor Inválido");
                txtValorC.Focus();
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            //verificando se os valores formam um triangulo
            if ((valorA < (valorB + valorC)) && (valorB < (valorA + valorC)) && (valorC < (valorA + valorB)))
            {
                //MessageBox.Show("Os valores pertencem aos lados de um triangulo!");
                //verificando de é equilátero (todos os lados iguais)
                if ((valorA == valorB) && (valorB == valorC))
                {
                    MessageBox.Show("O triângulo é equilátero!");
                }
                else  //verificando e é isoceles (dois lados iguais)
                {
                    if ((valorA == valorB) || (valorA == valorC) || (valorC == valorB)){
                        MessageBox.Show("O triângulo é isósceles");
                    }
                    else
                    {
                        //é escaleno
                        MessageBox.Show("O triângulo é escaleno");
                    }
                }                          
           }
            else
            {
                MessageBox.Show("Os lados informados não formam um triângulo!");
            }
            
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja realmente sair?",
                "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }

        }
       

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorA.Text,out valorA) || (valorA <= 0))
            {
                MessageBox.Show("Valor Inválido");
                txtValorA.Focus();
            }
        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorB.Text, out valorB) || (valorB <= 0))
            {
                MessageBox.Show("Valor Inválido");
                txtValorB.Focus();
            }
        }

        

    }
}
