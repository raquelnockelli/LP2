﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    abstract internal class Empregado
    {
        // private so vale dentro da propria classe o publico todo mundo pode ver
        private int matricula; //atributo
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        public int Matricula // propriedade esta com M maiusculo pq não pode ter o mesmo nome do atributo
        {
            get { return matricula; }
            set { matricula = value; }

        }

        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }

        }

        // metodos são açoes/comportamentos
        //virtual -> pode ser sobreescrito - o virtual autoriza o a sobreescrever o metodo principal
        // Time.Span guarda um intervalo de tempo
        public virtual int TempoTrabalho()
        {
            // representa um intervalo de tempo
            TimeSpan span =
            DateTime.Today.Subtract(DataEntradaEmpresa);
            return (span.Days);
        }

        //deve ser implementado
        // Derived classes must implement this
        // toda classe com metodo abstrato se torna abstrata, classe abstrata não permite criar objetos dela

        public abstract double SalarioBruto();

        public Empregado()
        {
            System.Windows.Forms.MessageBox.Show("Aqui é empregado");
        }

        public Empregado(int mat, string nome, DateTime datax)
            matricula = mat;
            nomeEmpregado = nome;
            dataEntradaEmpresa = datax;



    }
}
