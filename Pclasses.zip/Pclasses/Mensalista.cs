﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//aqui so vamo cria a propriedade
namespace Pclasses
{
    internal class Mensalista : Empregado
    {
        //escreve prop + tab tab (atalho para criar propriedade)        
        public Double SalarioMensal {  get; set; }
        // escrito o get e o set dessa forma não da pra colocar mais codigo

        //sobreescrevendo o metodo (overrride)
        public override double SalarioBruto()
        {
            return SalarioMensal;
        }
        public Mensalista()
        {
            System.Windows.Forms.MessageBox.Show("Aqui é mensalista");

        }

        public Mensalista (int matx, string nomex, DateTime datax, 
            double salx)
        {
            this.NomeEmpregado = nomex;
            this.Matricula = matx;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;
        }
        public static String Empresa = "Toyota";
        public const String Filial = "Filial Sorocaba";

    }

   
    
}
